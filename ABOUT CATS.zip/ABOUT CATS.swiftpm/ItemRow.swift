import SwiftUI

// 顯示存儲項目資訊的行視圖
struct ItemRow: View {
    // 傳入的 Store 型別的名稱
    let name: Store
    
    var body: some View {         
        // 垂直佈局，對齊方式為左對齊
        VStack(alignment: .leading) {
            // 顯示存儲項目的 id
            Text(name.id)
            // 顯示存儲項目的名稱
            Text(name.name) 
        }
    }
}
