import TipKit

// 自定義提示 PopoverTip 實現 Tip 協議
struct PopoverTip: Tip {
    
    // 提示的標題
    var title: Text {
        Text("更新其他貓咪照片")
    }
    
    // 提示的內容信息
    var message: Text? {
        Text("由上往下滑動更新")
    }
    
    // 提示的圖片，這裡使用系統提供的 "bell" 圖標
    var image: Image? {
        Image(systemName: "bell")
    }
}

// 自定義提示 PopoverTip2 實現 Tip 協議
struct PopoverTip2: Tip {
    
    // 提示的標題
    var title: Text {
        Text("搜尋貓咪品種")
    }
    
    // 提示的內容信息
    var message: Text? {
        Text("按下搜尋框並輸入品種名稱 或是 從下方的所有品種中找尋")
    }
    
    // 提示的圖片，這裡使用系統提供的 "bell" 圖標
    var image: Image? {
        Image(systemName: "bell")
    }
}
