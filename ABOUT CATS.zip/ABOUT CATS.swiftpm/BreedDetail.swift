import SwiftUI

// 定義一個 SwiftUI 的 View，用來顯示特定品種的詳細資訊
struct BreedDetail: View {
    // 透過 Environment 屬性注入一個名為 DataFetcher 的依賴，用於資料的獲取
    @Environment(DataFetcher.self) var fetcher
    // 儲存特定品種的資訊
    var bee: StoreBreed
    
    // 主要的視圖內容
    var body: some View {
        VStack {
            // 顯示標題，表示關於該品種的資訊
            Text("About This Breed")
                .font(.title)
                .foregroundColor(.indigo)
            
            // 包含品種的基本資訊的 VStack
            VStack {
                Text("ID: \(bee.id)")
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text("Breed: \(bee.name)")
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text("Description: \(bee.description)")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding()
            // 加上一個圓角矩形邊框
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.black, lineWidth: 1)
            )
            
            // 如果有 Wikipedia 的連結，顯示一個超連結
            if let wikipedia_url = bee.wikipedia_url {
                Link("WIKIPEDIA", destination: wikipedia_url)
                    .foregroundColor(.orange)
                    .bold()
            }
            
            // 顯示分享連結的橫向 HStack
            HStack {
                ShareLink("ID", item: bee.id)
                ShareLink("BREED", item: bee.name)
                ShareLink("DESCRIPTION", item: bee.description)
            }
            .offset(y: 10)
        }
        .padding()
        // 設定導覽標題為品種的名稱
        .navigationTitle(bee.name)
    }
}
