import Foundation

// 表示從 API 獲取的貓咪信息的模型，實現 Codable 和 Identifiable 協議
struct StoreItem: Codable, Identifiable {
    var id: String
    let url: String
    var breeds: [Store] = [] // 貓咪的品種信息
    let width: Int
    let height: Int
    
    // 定義編碼和解碼時的屬性映射關係
    enum CodingKeys: String, CodingKey {
        case id
        case url
        case width
        case height
    }
}

// 表示從 API 獲取的貓咪名稱信息的模型，實現 Codable 和 Identifiable 協議
struct StoreName: Codable, Identifiable {
    let id: String
    let url: String
    let breeds: [Store]? // 貓咪的品種信息
    let width: Int
    let height: Int
}

// 表示貓咪品種的模型，實現 Codable 和 Identifiable 協議
struct Store: Codable, Identifiable {
    let id: String
    let name: String
    let temperament: String
    let origin: String
    let description: String
    let life_span: String
    let wikipedia_url: URL
}

// 表示貓咪品種的模型，實現 Codable 和 Identifiable 協議
struct StoreBreed: Codable, Identifiable {
    let id: String
    let name: String
    let description: String
    let wikipedia_url: URL? // 品種的維基百科頁面連結
}
