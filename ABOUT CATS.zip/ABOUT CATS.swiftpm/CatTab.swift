import SwiftUI
import Pow
import Foundation

// 負責管理使用者喜愛的貓的類別，使用 ObservableObject 進行數據綁定
class FavoritesManager: ObservableObject {
    static let shared = FavoritesManager()
    
    // 使用 @Published 屬性監聽 favoriteCats 陣列的變化，同時保存到 UserDefaults 中
    @Published var favoriteCats: [StoreItem] = [] {
        didSet {
            saveFavoritesToUserDefaults()
        }
    }
    
    private let favoritesKey = "FavoriteCats"
    
    // 初始化時載入 UserDefaults 中保存的喜愛貓的數據
    init() {
        loadFavoritesFromUserDefaults()
    }
    
    // 切換貓的喜愛狀態，如果已經收藏，則移除；如果未收藏，則添加
    func toggleFavorite(_ cat: StoreItem) {
        if let index = favoriteCats.firstIndex(where: { $0.id == cat.id }) {
            favoriteCats.remove(at: index)
        } else {
            favoriteCats.append(cat)
        }
    }
    
    // 將喜愛貓的數據保存到 UserDefaults
    private func saveFavoritesToUserDefaults() {
        let data = try? JSONEncoder().encode(favoriteCats)
        UserDefaults.standard.set(data, forKey: favoritesKey)
    }
    
    // 從 UserDefaults 中載入喜愛貓的數據
    private func loadFavoritesFromUserDefaults() {
        if let data = UserDefaults.standard.data(forKey: favoritesKey) {
            if let decodedFavorites = try? JSONDecoder().decode([StoreItem].self, from: data) {
                favoriteCats = decodedFavorites
            }
        }
    }
}

// 顯示貓的詳細資訊的視圖
struct Detail: View {
    // 用於追蹤是否為喜愛的狀態
    @State var isFavorited: Bool = false
    
    let rea: StoreItem
    var body: some View {
        HStack(spacing:20) {
            // 顯示貓的基本資訊
            ReaRow(rea: rea)
            ShareLink("Image", item: rea.url)
            
            // 喜愛按鈕的部分
            VStack {
                Label {
                    Text("Like")
                        .font(.headline)
                        .foregroundColor(isFavorited ? .pink : .secondary)
                } icon: {
                    ZStack{
                        Image(systemName: "heart")
                            .foregroundColor(.gray)
                            .fontWeight(.light)
                            .opacity(isFavorited ? 0 : 1)
                        
                        Image(systemName: "heart.fill")
                            .foregroundStyle(.pink.gradient)
                            .scaleEffect(isFavorited ? 1 : 0.1, anchor: .center)
                            .opacity(isFavorited ? 1 : 0)
                    }
                    .changeEffect(.spray {
                        Group {
                            Image(systemName: "heart.fill")
                            Image(systemName: "sparkles")
                        }
                        .font(.title)
                        .foregroundStyle(.pink.gradient)
                    }, value: isFavorited)
                }
                .padding(.vertical, 8)
                .padding(.horizontal, 16)
                .background {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(.foreground)
                        .opacity(0.3)
                }
                .onTapGesture {
                    withAnimation(.movingParts.overshoot(duration: 0.4)) {
                        isFavorited.toggle()
                        FavoritesManager.shared.toggleFavorite(rea)
                    }
                }
            }
        }
        
        // 顯示貓的詳細資訊
        VStack {
            Text("About This Cat")
                .font(.title)
                .foregroundColor(.indigo)
            VStack(alignment: .leading) {
                Text("Temperament: \(rea.breeds.map { $0.temperament }.joined(separator: ","))")
                Text("Origin: \(rea.breeds.map { $0.origin }.joined(separator: ","))")
                Text("Life_span: \(rea.breeds.map { $0.life_span }.joined(separator: ","))")
                Text("Width: \(String(rea.width))")
                Text("Height: \(String(rea.height))")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }.offset(x:10).padding()
        }
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.black, lineWidth: 1)
        )
        .offset(y:10)
        
        // 顯示貓品種的詳細資訊
        VStack {
            HStack {
                Text("About This Breed")
                    .font(.title)
                    .foregroundColor(.indigo)
                    .frame(alignment: .center)
                
                // 顯示品種相關的超連結
                VStack {
                    ForEach(rea.breeds) { breed in 
                        Link("WIKIPEDIA", destination: breed.wikipedia_url)
                            .foregroundColor(.orange)
                            .bold()
                    }
                }.offset(x:10)
            }.offset(x:50)
            VStack(alignment: .leading) {
                Text("Breed: \(rea.breeds.map { $0.name }.joined(separator: ","))")
                Text("Description: \(rea.breeds.map { $0.description }.joined(separator: ","))")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }.offset(x:10).padding()
        }
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color.black, lineWidth: 1)
        )            
        .offset(y:20)
        
        // 設定導覽標題
        .navigationBarTitle("More Detail")
    }
}

// 顯示隨機貓圖片的視圖
struct CatTab: View {
    // 透過 Environment 屬性注入一個名為 DataFetcher 的依賴，用於資料的獲取
    @Environment(DataFetcher.self) var fetcher
    @State private var showError = false
    @State private var error: Error?
    @State var progressValue = 0.0
    let timer = Timer.publish(every: 1, on: .main, in: .default).autoconnect()
    var tip = PopoverTip()
    
    var body: some View {
        ZStack {
            NavigationStack {
                VStack {
                    // 顯示錯誤畫面
                    if showError {
                        if error?.localizedDescription == "The data couldn't be read because it is missing." {
                            ContentUnavailableView(
                                "No matchable CAT data😢",
                                image: "",
                                description: Text("Please check your API.")
                            )
                        }
                        if error?.localizedDescription == "網際網路連線已斷開。" {
                            ContentUnavailableView(
                                "Internet may be offline🛜",
                                systemImage: "exclamationmark.triangle.fill",
                                description: Text("Please check your Internet connection.")
                            )
                        } 
                        if error?.localizedDescription == "The operation couldn't be completed. (AppModule.DataFetcher.FetchError error 1.)" {
                            ContentUnavailableView(
                                "Something went wrong😵",
                                image: "",
                                description: Text("Please refresh.")
                            )
                        }
                    }
                    
                    // 顯示正常的畫面
                    if !showError {
                        // 處理資料還在載入的情況
                        if fetcher.reas.isEmpty {
                            ContentUnavailableView(label: {
                                ProgressView(value: progressValue)
                                    .progressViewStyle(.circular)
                            }, description: {
                                Text("Loading...")
                                Text("\(progressValue*100, specifier: "%.2f")%")
                            })
                        }
                        
                        // 顯示提示框
                        Image(systemName: "wand.and.stars.inverse")
                            .imageScale(.large)
                            .popoverTip(tip)
                            .onTapGesture {
                                tip.invalidate(reason: .actionPerformed)
                            }
                            .offset(x:350, y:-45)
                        
                        // 顯示貓的列表
                        List {
                            ForEach(fetcher.reas) { rea in
                                NavigationLink {
                                    Detail(rea: rea)
                                } label: {
                                    ReaRow(rea: rea)
                                        .onAppear(perform: {
                                            Task {
                                                try await  fetcher.fetchName(term: rea.id)
                                            }
                                        })
                                }
                            }
                        }
                    }
                }
                
                // 處理畫面還在載入的情況
                .task {
                    if fetcher.reas.isEmpty {
                        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in 
                            withAnimation {
                                if progressValue >= 1.0 {
                                    timer.invalidate()
                                } else {
                                    progressValue += 0.1
                                    if progressValue >= 1.0 {
                                        progressValue = 1.0
                                    }
                                }
                            }
                        } // Loading時進度條的動畫
                        do {
                            try await  fetcher.fetchData()
                        } catch {
                            self.error = error
                            print(error.localizedDescription ?? "")
                            showError = true
                        }
                    }
                }
                
                // 下拉刷新時重新加載資料
                .refreshable {
                    do {
                        try await fetcher.fetchData()
                    } catch {
                        self.error = error
                        print(error.localizedDescription ?? "")
                        showError = true
                    }
                }
                
                // 設定導覽標題
                .navigationTitle("Random Cat Image")
            }
        }
    }
}

// 預覽視圖
#Preview {
    CatTab()
        .environment(DataFetcher())
}
