import SwiftUI

// 定義一個 SwiftUI 的 View，用於顯示貓品種的資訊
struct CatBreed: View {
    // 透過 Environment 屬性注入一個名為 DataFetcher 的依賴，用於資料的獲取
    @Environment(DataFetcher.self) var fetcher
    
    // 使用 @State 屬性來追蹤錯誤顯示的狀態、錯誤對象、搜尋文字、進度條值
    @State private var showError = false
    @State private var error: Error?
    @State private var searchText = ""
    @State var progressValue = 0.0
    
    // 使用 Timer 來實現進度條的動畫效果
    let timer = Timer.publish(every: 1, on: .main, in: .default).autoconnect()
    
    // 定義 PopoverTip2 來顯示提示框
    var tip2 = PopoverTip2()
    
    // 用於顯示搜尋結果的計算屬性
    var searchResult: [StoreBreed] {
        let search = searchText
        if searchText == "" {
            Task{
                // 當搜尋文字為空時，執行非同步任務從網路獲取貓品種資料
                do {
                    try await fetcher.fetchBreed()
                } catch {
                    self.error = error
                    showError = true
                }
            }
            // 返回所有的貓品種資料
            return fetcher.bees
        } else {
            // 當搜尋文字不為空時，篩選包含搜尋文字的貓品種資料
            return search == nil ? fetcher.bees :
            fetcher.bees.filter{ $0.name.contains(search)}
        }
    }
    
    // 主要的視圖內容
    var body: some View {
        NavigationStack {
            VStack {
                // 顯示貓品種的列表
                List {
                    // 當發生錯誤時顯示相應的畫面
                    if showError {
                        if error?.localizedDescription == "The data couldn't be read because it is missing." {
                            ContentUnavailableView(
                                "No matchable Cat Breed data😢",
                                image: "",
                                description: Text("Please check your API.")
                            )
                        }
                        if error?.localizedDescription == "網際網路連線已斷開。" {
                            ContentUnavailableView(
                                "Internet may be offline🛜",
                                systemImage: "exclamationmark.triangle.fill",
                                description: Text("Please check your Internet connection.")
                            )
                        }
                        if error?.localizedDescription == "The operation couldn't be completed. (AppModule.DataFetcher.FetchError error 1.)" {
                            ContentUnavailableView(
                                "Something went wrong😵",
                                image: "",
                                description: Text("Please refresh.")
                            )
                        }
                    }
                    
                    // 當沒有錯誤時，顯示不同的畫面
                    if !showError {
                        // 當貓品種資料為空時，顯示 Loading 畫面
                        if fetcher.bees.isEmpty {
                            ContentUnavailableView(label: {
                                ProgressView(value: progressValue)
                                    .progressViewStyle(.circular)
                            }, description: {
                                Text("Loading...")
                                Text("\(progressValue*100, specifier: "%.2f")%")
                            })
                        }
                        
                        // 當 Loading 完成時，顯示貓品種的列表
                        if progressValue == 1 {
                            ForEach(searchResult) { breed in
                                NavigationLink {
                                    BreedDetail(bee: breed)
                                } label: {
                                    Text(breed.name)
                                }
                            }
                        }
                        
                        // 在畫面右上角顯示一個提示框
                        Image(systemName: "wand.and.stars.inverse")
                            .imageScale(.large)
                            .popoverTip(tip2)
                            .onTapGesture {
                                tip2.invalidate(reason: .actionPerformed)
                            }
                            .offset(x:700, y:-270)
                    }
                }
            }
            
            // 使用 Task 來設定進度條的動畫效果
            .task {
                Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in
                    withAnimation {
                        if progressValue >= 1.0 {
                            timer.invalidate()
                        } else {
                            progressValue += 0.1
                            if progressValue >= 1.0 {
                                progressValue = 1.0
                            }
                        }
                    }
                }
            }
            
            // 在下拉刷新時重新加載資料
            .refreshable {
                Task {
                    do {
                        try await fetcher.fetchData()
                    } catch {
                        self.error = error
                        print(error.localizedDescription ?? "")
                        showError = true
                    }
                }
            }
            
            // 如果搜尋文字不為空且搜尋結果為空，顯示查無資料的畫面
            .overlay {
                if !searchText.isEmpty, searchResult.isEmpty {
                    ContentUnavailableView.search
                }
            }
            
            // 設定導覽標題為 "Cat Breed"
            .navigationTitle("Cat Breed")
        }
        
        // 使用 searchable 屬性實現搜尋功能
        .searchable(text: $searchText, placement: .navigationBarDrawer)
    }
}

// 預覽視圖
#Preview {
    CatBreed()
        .environment(DataFetcher())
}
