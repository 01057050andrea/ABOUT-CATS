import SwiftUI
import TipKit

// 主應用程式的主視圖，包含四個頁籤：首頁、貓圖片、貓品種、喜愛的貓
struct ContentView: View {
    // 使用 @State 屬性來儲存 DataFetcher 實例
    @State private var fetcher = DataFetcher()
    
    var body: some View {
        VStack(spacing: 20) {
            // 使用 TabView 包裝四個不同的視圖
            TabView {
                // 首頁視圖
                HomePage()
                    .tabItem {
                        Image(systemName: "house.fill")
                        Text("HOME")
                    }
                
                // 貓圖片視圖
                CatTab()
                    .tabItem { 
                        Image(systemName: "cat")
                        Text("CAT")
                    }
                
                // 貓品種視圖
                CatBreed()
                    .tabItem { 
                        Image(systemName: "magnifyingglass")
                        Text("CATBREED")
                    }
                
                // 喜愛的貓視圖
                FavoritesView()
                    .tabItem {
                        Image(systemName: "heart")
                        Text("LIKE")
                    }
            }
        }
        // 透過 environment 屬性將 DataFetcher 實例注入整個視圖樹
        .environment(fetcher)
    }
}
