import SwiftUI

// 首頁視圖，顯示一張貓咪的圖片
struct HomePage: View {
    var body: some View {
        // 使用 Image 顯示名為 "CatPic" 的圖片，並設定圖片的縮放屬性
        Image("CatPic")
            .resizable()
            .scaledToFill()
    }
}

// 預覽視圖，用於預覽 HomePage 的外觀
#Preview {
    HomePage()
}
