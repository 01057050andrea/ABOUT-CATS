import SwiftUI

// 顯示貓咪信息的行視圖
struct ReaRow: View {
    // 傳入的 StoreItem 型別的貓咪信息
    let rea: StoreItem
    
    var body: some View {        
        // 水平佈局，對齊方式為中心對齊
        HStack(alignment: .center) {
            // 使用 AsyncImage 顯示異步載入的圖片，當圖片載入時顯示動畫效果
            AsyncImage(url: URL(string: rea.url)) { image in
                image
                    .resizable()
            } placeholder: {
                // 圖片載入前顯示的預設圖片
                Image("animal")
                    .resizable()
            }
            // 設定圖片的縮放、大小和裁剪屬性
            .scaledToFill()
            .frame(width: 200, height: 200)
            .clipped()
            
            // 顯示貓咪品種的名稱，使用逗號分隔多個品種名稱
            Text(rea.breeds.map { $0.name }.joined(separator: ","))
        }
    }
}
