import Foundation

// 定義一個具有 Observable 功能的資料獲取器類別
@Observable class DataFetcher {
    // 存儲貓圖片資料的陣列
    var reas = [StoreItem]()
    // 存儲貓品種資料的陣列
    var bees = [StoreBreed]()
    
    // 定義一個錯誤列舉，用於處理資料獲取時的錯誤
    enum FetchError: Error {
        case invalidURL
        case badRequest
    }
    
    // 獲取貓圖片資料的非同步函數
    func fetchData() async throws {
        // 定義 API 的 URL 字串
        let urlString = "https://api.thecatapi.com/v1/images/search?limit=25&api_key=live_peUb4OCTdcirIA9H4D04LOgD6rBGC4xaa4k7eucqsB8bNdJj98I9gjksV3aiLJjl&has_breeds=1"
        
        // 將 URL 字串轉換為 URL
        guard let url = URL(string: urlString) else {
            throw FetchError.invalidURL
        }
        
        // 使用 URLSession 發送網路請求並獲取數據
        let (data, response) = try await URLSession.shared.data(from: url)
        
        // 檢查 HTTP 響應狀態碼是否為 200，否則拋出錯誤
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw FetchError.badRequest
        }
        
        // 將獲取到的數據印出
        print(String(data: data, encoding: .utf8)!)
        
        // 使用 JSONDecoder 將數據解碼為 StoreItem 類型的陣列
        do {
            let storeItem = try JSONDecoder().decode([StoreItem].self, from: data)
            
            // 寫法 1：直接賦值給 reas
            reas = storeItem
        } catch DecodingError.keyNotFound(let key, let context) {
            print("keyNotFound", key, context)
        } catch DecodingError.typeMismatch(let type, let context) {
            print("typeMismatch", type, context)
        } catch DecodingError.valueNotFound(let value, let context) {
            print("valueNotFound", value, context)
        } catch DecodingError.dataCorrupted(let context) {
            print("dataCorrupted", context)
        } catch  {
            print(error)
        }
    }
    
    // 獲取貓名稱資料的非同步函數
    func fetchName(term: String) async throws {
        // 定義 API 的 URL 字串
        let urlString = "https://api.thecatapi.com/v1/images/\(term)"
        
        // 將 URL 字串轉換為 URL
        guard let url = URL(string: urlString) else {
            throw FetchError.invalidURL
        }
        
        // 使用 URLSession 發送網路請求並獲取數據
        let (data, response) = try await URLSession.shared.data(from: url)
        
        // 檢查 HTTP 響應狀態碼是否為 200，否則拋出錯誤
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw FetchError.badRequest
        }
        
        // 使用 JSONDecoder 將數據解碼為 StoreName 類型
        do {
            let storeName = try JSONDecoder().decode(StoreName.self, from: data)
            
            // 寫法 1：更新 reas 中對應的貓的品種資料
            let index = reas.firstIndex {
                $0.id == term
            }
            if let index {
                reas[index].breeds = storeName.breeds ?? []
                print("update", index, reas[index].breeds)
            }
        } catch DecodingError.keyNotFound(let key, let context) {
            print("keyNotFound", key, context)
        } catch DecodingError.typeMismatch(let type, let context) {
            print("typeMismatch", type, context)
        } catch DecodingError.valueNotFound(let value, let context) {
            print("valueNotFound", value, context)
        } catch DecodingError.dataCorrupted(let context) {
            print("dataCorrupted", context)
        } catch  {
            print(error)
        }
    }
    
    // 獲取貓品種資料的非同步函數
    func fetchBreed() async throws {
        // 定義 API 的 URL 字串
        let urlString = "https://api.thecatapi.com/v1/breeds"
        
        // 將 URL 字串轉換為 URL
        guard let url = URL(string: urlString) else {
            throw FetchError.invalidURL
        }
        
        // 使用 URLSession 發送網路請求並獲取數據
        let (data, response) = try await URLSession.shared.data(from: url)
        
        // 檢查 HTTP 響應狀態碼是否為 200，否則拋出錯誤
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw FetchError.badRequest
        }
        
        // 使用 JSONDecoder 將數據解碼為 StoreBreed 類型的陣列
        do {
            let storeBreed = try JSONDecoder().decode([StoreBreed].self, from: data)
            
            // 寫法 1：直接賦值給 bees
            bees = storeBreed
        } catch DecodingError.keyNotFound(let key, let context) {
            print("keyNotFound", key, context)
        } catch DecodingError.typeMismatch(let type, let context) {
            print("typeMismatch", type, context)
        } catch DecodingError.valueNotFound(let value, let context) {
            print("valueNotFound", value, context)
        } catch DecodingError.dataCorrupted(let context) {
            print("dataCorrupted", context)
        } catch  {
            print(error)
        }
    }
}
