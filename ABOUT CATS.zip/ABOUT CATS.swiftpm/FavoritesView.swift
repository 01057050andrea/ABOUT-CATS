import SwiftUI

// 顯示使用者喜愛的貓咪清單的視圖
struct FavoritesView: View {
    // 使用 ObservedObject 屬性監視 FavoritesManager 的變化
    @ObservedObject var favoritesManager = FavoritesManager.shared
    
    var body: some View {
        // 使用 NavigationView 包裝列表視圖，以便將來能夠進行導航
        NavigationView {
            // 顯示喜愛的貓咪清單的列表
            List(favoritesManager.favoriteCats) { cat in
                // 點擊列表項目後，導航到詳細信息視圖
                NavigationLink(destination: Detail(isFavorited: true, rea: cat)) {
                    // 在此顯示猫咪的信息，例如圖像、名稱等
                    ReaRow(rea: cat)
                }
            }
            // 設定導覽列標題
            .navigationTitle("Favorite Cats")
        }
    }
}
