import SwiftUI
import TipKit

// App 的入口點
@main
struct MyApp: App {
    var body: some Scene {
        // 定義應用程式的主視窗
        WindowGroup {
            // 使用 ContentView 作為主視窗的內容
            ContentView()
            // 在視窗首次顯示時執行的動作
                .onAppear {
                    FavoritesManager.shared // 初始化 FavoritesManager，確保已經加載喜愛管理器
                }
        }
    }
    
    // 應用程式的初始化方法
    init() {
        // 顯示所有提示，用於測試目的
        Tips.showAllTipsForTesting()
        // 設定 TipKit 的配置，這可能會涉及一些全局設置
        try? Tips.configure()
    }                                       
}
